import React, { useState, useEffect, useRef } from "react";
import { v4 as uuidv4 } from "uuid";
import "./App.css";

export default function App() {
  const [sprite1Blocks, setSprite1Blocks] = useState([]);
  const [sprite2Blocks, setSprite2Blocks] = useState([]);
  const [runAll, setRunAll] = useState(false);
  const [collision, setCollision] = useState(false);

  const addBlock = (sprite, type) => {
    const newBlock = {
      id: uuidv4(),
      type,
      value: type === "say" ? "Hello!" : 20,
    };

    if (sprite === 1) setSprite1Blocks((prev) => [...prev, newBlock]);
    else setSprite2Blocks((prev) => [...prev, newBlock]);
  };

  const updateBlock = (sprite, index, updatedBlock) => {
    const updater = sprite === 1 ? setSprite1Blocks : setSprite2Blocks;
    const blocks = sprite === 1 ? sprite1Blocks : sprite2Blocks;
    const newBlocks = [...blocks];
    newBlocks[index] = updatedBlock;
    updater(newBlocks);
  };

  const handleRun = () => {
    setCollision(false);
    setRunAll(false);
    setTimeout(() => setRunAll(true), 100); // reset trigger
  };

  return (
    <div className="p-4 space-y-4">
      <div className="flex gap-10">
        <BlockPalette sprite={1} addBlock={addBlock} />
        <Canvas sprite={1} blocks={sprite1Blocks} updateBlock={updateBlock} />
        <BlockPalette sprite={2} addBlock={addBlock} />
        <Canvas sprite={2} blocks={sprite2Blocks} updateBlock={updateBlock} />
      </div>

      <button onClick={handleRun} className="p-2 px-6 bg-green-600 text-white rounded">
        Run All
      </button>

      <div className="relative h-[400px] bg-blue-100 rounded overflow-hidden mt-4">
        <Sprite
          id="sprite1"
          commands={sprite1Blocks}
          run={runAll}
          color="bg-orange-400"
          startX={50}
          onCollision={() => setCollision(true)}
        />
        <Sprite
          id="sprite2"
          commands={sprite2Blocks}
          run={runAll}
          color="bg-pink-400"
          startX={200}
          onCollision={() => setCollision(true)}
        />
        {collision && (
          <div className="absolute top-2 left-1/2 transform -translate-x-1/2 bg-red-500 text-white px-4 py-2 rounded">
            Collision Detected!
          </div>
        )}
      </div>
    </div>
  );
}

function BlockPalette({ sprite, addBlock }) {
  return (
    <div className="p-4 bg-gray-100 rounded shadow">
      <h2 className="font-bold mb-2">Sprite {sprite} Blocks</h2>
      <button onClick={() => addBlock(sprite, "moveRight")} className="block mb-1 p-1 bg-blue-300 rounded">Move Right</button>
      <button onClick={() => addBlock(sprite, "moveLeft")} className="block mb-1 p-1 bg-blue-300 rounded">Move Left</button>
      <button onClick={() => addBlock(sprite, "moveUp")} className="block mb-1 p-1 bg-yellow-300 rounded">Move Up</button>
      <button onClick={() => addBlock(sprite, "moveDown")} className="block mb-1 p-1 bg-yellow-300 rounded">Move Down</button>
      <button onClick={() => addBlock(sprite, "say")} className="block mb-1 p-1 bg-purple-300 rounded">Say</button>
    </div>
  );
}

function Canvas({ sprite, blocks, updateBlock }) {
  return (
    <div className="p-4 bg-white border min-w-[200px] rounded">
      <h3 className="font-semibold">Sprite {sprite} Code</h3>
      {blocks.map((block, i) => (
        <div key={block.id} className="m-2 p-2 bg-gray-200 rounded">
          {block.type}
          <input
            className="ml-2 p-1 w-20 rounded"
            type={block.type === "say" ? "text" : "number"}
            value={block.value}
            onChange={(e) => updateBlock(sprite, i, { ...block, value: block.type === "say" ? e.target.value : +e.target.value })}
          />
        </div>
      ))}
    </div>
  );
}

function Sprite({ id, commands, run, color, startX, onCollision }) {
  const ref = useRef();
  const pos = useRef({ x: startX, y: 150 });

  useEffect(() => {
    if (!run) return;

    let x = pos.current.x;
    let y = pos.current.y;

    const execute = async () => {
      for (const cmd of commands) {
        switch (cmd.type) {
          case "moveRight":
            x += cmd.value;
            break;
          case "moveLeft":
            x -= cmd.value;
            break;
          case "moveUp":
            y -= cmd.value;
            break;
          case "moveDown":
            y += cmd.value;
            break;
          case "say":
            alert(`${id} says: ${cmd.value}`);
            break;
          default:
            break;
        }

        ref.current.style.transform = `translate(${x}px, ${y}px)`;
        pos.current = { x, y };

        // Check for collision
        const otherSprite = document.getElementById(id === "sprite1" ? "sprite2" : "sprite1");
        if (otherSprite) {
          const rect1 = ref.current.getBoundingClientRect();
          const rect2 = otherSprite.getBoundingClientRect();

          if (
            rect1.left < rect2.right &&
            rect1.right > rect2.left &&
            rect1.top < rect2.bottom &&
            rect1.bottom > rect2.top
          ) {
            onCollision();
          }
        }

        await new Promise((r) => setTimeout(r, 500));
      }

      pos.current = { x, y };
    };

    execute();
  }, [run]);

  return (
    <div
      id={id}
      ref={ref}
      className={`absolute w-16 h-16 ${color} text-white flex items-center justify-center rounded-full transition-all duration-300`}
      style={{ transform: `translate(${startX}px, 150px)` }}
    >
      {id === "sprite1" ? "🐱" : "🐶"}
    </div>
  );
}


